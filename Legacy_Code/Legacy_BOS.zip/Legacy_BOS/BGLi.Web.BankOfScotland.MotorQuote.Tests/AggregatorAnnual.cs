using BGLi.Web.MotorQuote.EndToEndTests.QuoteData;

namespace BGLi.Web.BankOfScotland.MotorQuote.Tests;

public class AggregatorAnnual : BaseTest
{
    [Test]
    [Category("Aggregator")]
    public async Task As_An_Aggregator_Customer_With_Quotable_Details_I_Can_Buy_An_Annual_Policy()
    {
        try
        {
            var steps = new BaseSteps(WebDriver);

            var quoteLink = await DataService.GetQuoteUrl("SC9M", PaymentFrequency.Annual);

            if (quoteLink is null)
                Assert.Fail("WAS did not return a quote");

            WebDriver.Navigate().GoToUrl(quoteLink);

            steps.AcceptCookies();
            steps.PricePresentation();
            steps.OptionalExtras_NoClaimsProtection();
            steps.OptionalExtras_LegalProtection();
            steps.OptionalExtras_ReplacementCar();
            steps.OptionalExtras_KeyCare();
            steps.OptionalExtras_BreakdownCover();
            steps.OptionalExtras_Continue();
            steps.OneMoreThing();
            steps.PolicyOverview();
            steps.CardPayment();
            steps.AnnualSummary();
            steps.MyAccountRegistration(includeSecurityQuestion: true);

            Assert.That(WebDriver.Url, Does.EndWith("/MyAccount/PolicyOverview/Vehicle"));
        }
        catch (Exception ex)
        {
            HandleError(ex);
        }
    }
}