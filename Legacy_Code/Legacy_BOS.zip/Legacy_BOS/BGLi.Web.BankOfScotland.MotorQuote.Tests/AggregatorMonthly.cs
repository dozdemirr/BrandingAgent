using BGLi.Web.MotorQuote.EndToEndTests.QuoteData;

namespace BGLi.Web.BankOfScotland.MotorQuote.Tests;

public class AggregatorMonthly : BaseTest
{
    [Test]
    [Category("Aggregator")]
    public async Task As_An_Aggregator_Customer_With_Quotable_Details_I_Can_Buy_A_Monthly_Policy()
    {
        try
        {
            var steps = new BaseSteps(WebDriver);

            var quoteLink = await DataService.GetQuoteUrl("SC9M", PaymentFrequency.Monthly);

            if (quoteLink is null)
                Assert.Fail("WAS did not return a quote");

            WebDriver.Navigate().GoToUrl(quoteLink);

            steps.AcceptCookies();
            steps.PricePresentation();
            steps.OptionalExtras_NoClaimsProtection();
            steps.OptionalExtras_LegalProtection();
            steps.OptionalExtras_ReplacementCar();
            steps.OptionalExtras_KeyCare();
            steps.OptionalExtras_BreakdownCover();
            steps.OptionalExtras_Continue();
            steps.OneMoreThing();
            steps.PolicyOverview();
            steps.MonthlyPayment();
            steps.CardPayment();
            steps.MonthlySummary();
            steps.MyAccountRegistration(includeSecurityQuestion: true);

            Assert.That(WebDriver.Url, Does.EndWith("/MyAccount/PolicyOverview/Vehicle"));
        }
        catch (Exception ex)
        {
            HandleError(ex);
        }
    }
}