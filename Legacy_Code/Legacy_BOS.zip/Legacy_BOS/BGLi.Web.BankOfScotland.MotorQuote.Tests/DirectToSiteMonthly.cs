namespace BGLi.Web.BankOfScotland.MotorQuote.Tests;

public class DirectToSiteMonthly : BaseTest
{
    [Test]
    [Category("DirectToSite")]
    public void As_A_DTS_Customer_With_Quotable_Details_I_Can_Buy_A_Monthly_Policy()
    {
        try
        {
            var steps = new BaseSteps(WebDriver);

            WebDriver.Navigate().GoToUrl($"{BaseUrl}/MotorQuote");

            steps.AcceptCookies();
            steps.GetAQuote();
            steps.AboutYou();
            steps.MaritalStatus();
            steps.Address();
            steps.HomeOwner();
            steps.Ukresident();
            steps.EmploymentStatus();
            steps.LicenseDetails();
            steps.MedicalConditions();
            steps.DeclinedInsurance();
            steps.MotorClaims();
            steps.MotorConvictions();
            steps.CriminalConvictions();
            steps.AddDriverNo();
            steps.VehicleRegistration();
            steps.Modifications();
            steps.VehiclePurchaseDetails();
            steps.OvernightParking();
            steps.CoverDetails();
            steps.MainDriver();
            steps.CoverLevel();
            steps.Excess();
            steps.StartDate();
            steps.AnnualMileage();
            steps.Usage();
            steps.NoClaimsDiscount();
            steps.OtherVehicles();
            steps.PaymentRegularityMonthly();
            steps.ContactDetails();
            steps.AllDone();
            steps.PricePresentation();
            steps.OptionalExtras_NoClaimsProtection();
            steps.OptionalExtras_LegalProtection();
            steps.OptionalExtras_ReplacementCar();
            steps.OptionalExtras_KeyCare();
            steps.OptionalExtras_BreakdownCover();
            steps.OptionalExtras_Continue();
            steps.AdditionalDetails();
            steps.MarketingPreferences();
            steps.MonthlyPayment();
            steps.CardPayment();
            steps.MonthlySummary();
            steps.MyAccountRegistration(includeSecurityQuestion: true);

            Assert.That(WebDriver.Url, Does.EndWith("/MyAccount/PolicyOverview/Vehicle"));
        }
        catch (Exception ex)
        {
            HandleError(ex);
        }
    }
}