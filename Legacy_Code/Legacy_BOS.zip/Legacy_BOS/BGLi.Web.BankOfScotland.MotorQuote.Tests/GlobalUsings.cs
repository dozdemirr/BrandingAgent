global using NUnit.Framework;
global using NUnit.Framework.Internal;
global using OpenQA.Selenium;
global using BGLi.Web.MotorQuote.EndToEndTests;