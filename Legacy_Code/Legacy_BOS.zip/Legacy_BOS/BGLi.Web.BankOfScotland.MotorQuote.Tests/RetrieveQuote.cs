namespace BGLi.Web.BankOfScotland.MotorQuote.Tests;

public class RetrieveQuote : BaseTest
{
    [Test]
    [Category("RetrieveQuote")]
    public void As_A_Customer_With_Quotable_Details_I_Can_Retrieve_And_Buy_A_Quote_I_Abandoned()
    {
        try
        {
            var steps = new BaseSteps(WebDriver);

            WebDriver.Navigate().GoToUrl($"{BaseUrl}/MotorQuote");

            steps.AcceptCookies();
            steps.GetAQuote();
            (var surname, var dateOfBirth) = steps.AboutYou();
            steps.MaritalStatus();
            steps.Address();
            steps.HomeOwner();
            steps.Ukresident();
            steps.EmploymentStatus();
            steps.LicenseDetails();
            steps.MedicalConditions();
            steps.DeclinedInsurance();
            steps.MotorClaims();
            steps.MotorConvictions();
            steps.CriminalConvictions();
            steps.AddDriverNo();
            steps.VehicleRegistration();
            steps.Modifications();
            steps.VehiclePurchaseDetails();
            steps.OvernightParking();
            steps.CoverDetails();
            steps.MainDriver();
            steps.CoverLevel();
            steps.Excess();
            steps.StartDate();
            steps.AnnualMileage();
            steps.Usage();
            steps.NoClaimsDiscount();
            steps.OtherVehicles();
            steps.PaymentRegularityAnnual();
            steps.ContactDetails();
            steps.AllDone();
            steps.PricePresentation();

            var originalQuoteId = steps.GetQuoteId();

            WebDriver.Navigate().GoToUrl($"{BaseUrl}/MotorQuote");

            steps.RetrieveQuote(originalQuoteId, surname, dateOfBirth);
            steps.PricePresentation();

            var retrievedQuoteId = steps.GetQuoteId();

            Assert.That(retrievedQuoteId, Is.EqualTo(originalQuoteId));
        }
        catch (Exception ex)
        {
            HandleError(ex);
        }
    }
}