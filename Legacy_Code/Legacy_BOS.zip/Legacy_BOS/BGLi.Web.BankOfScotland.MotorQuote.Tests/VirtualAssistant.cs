using BGLi.Web.MotorQuote.EndToEndTests.QuoteData;

namespace BGLi.Web.BankOfScotland.MotorQuote.Tests;

public class VirtualAssistant : BaseTest
{
    [Test]
    public async Task As_A_Customer_Who_Needs_Help_I_Can_Load_Virtual_Assistant()
    {
        try
        {
            var steps = new BaseSteps(WebDriver);

            var quoteLink = await DataService.GetQuoteUrl("SC9M", PaymentFrequency.Annual);

            if (quoteLink is null)
                Assert.Fail("WAS did not return a quote");

            WebDriver.Navigate().GoToUrl(quoteLink);

            steps.AcceptCookies();

            var quoteId = steps.GetQuoteId();

            steps.GetVirtualAssistantContext();

            var response = WebDriver.FindElements(By.ClassName("Twilio-MessageBubble-Body")).Last();

            Assert.That(response.Text, Does.Contain(quoteId));
        }
        catch (Exception ex)
        {
            HandleError(ex);
        }
    }
}