﻿namespace BGLi.Web.BankOfScotland.MotorQuote.Constants;

public class Constants
{
    public const string CustomerServicePhoneNumber = "0330 018 4175";

    public const string SalesPhoneNumber = "0330 018 1832";

    public const string VanErrorMessageUrl = "https://lloydsbankmotorinsurance.insure-systems.co.uk/Van/LV01/NLE";

    public const string WrongVehicleTypeForVanInsValidationErrorMessage = 
        "We have matched your vehicle to a van. Please click &lt;a href=\"{0}\"&gt;here&lt;/a&gt; to get a van insurance quote.";
}