using Microsoft.AspNetCore.Mvc;
using BGLi.Security.Web.Authentication.Controllers;

namespace BGLi.Web.BankOfScotland.MotorQuote.Controllers;

public class AdditionalDetailsController : SecuredController
{
    public ActionResult Index()
    {
        return View();
    }

    public ActionResult FinalAdditionalDetails()
    {
        return View();
    }
}