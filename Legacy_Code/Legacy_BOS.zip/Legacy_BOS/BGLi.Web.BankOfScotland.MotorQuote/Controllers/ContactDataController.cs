﻿using Microsoft.AspNetCore.Mvc;

namespace BGLi.Web.BankOfScotland.MotorQuote.Controllers;

public class ContactDataController : Controller
{
    // GET: ContactData
    public ActionResult HoustonContactData()
    {
        return PartialView("_HoustonContactData");
    }
}