using Microsoft.AspNetCore.Mvc;
using BGLi.Security.Web.Authentication.Controllers;

namespace BGLi.Web.BankOfScotland.MotorQuote.Controllers;

public class DocumentDownloadController : SecuredController
{
    public ActionResult Document()
    {
        return View();
    }
}