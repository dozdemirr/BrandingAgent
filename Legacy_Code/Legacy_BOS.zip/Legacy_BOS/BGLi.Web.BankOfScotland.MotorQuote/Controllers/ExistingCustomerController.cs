using Microsoft.AspNetCore.Mvc;

namespace BGLi.Web.BankOfScotland.MotorQuote.Controllers;

public class ExistingCustomerController : Controller
{
    public ActionResult Index()
    {
        return View();
    }

    public ActionResult RetrieveQuoteExistingCustomer()
    {
        return View();
    }
}