using Microsoft.AspNetCore.Mvc;
using BGLi.Security.Web.Authentication.Controllers;

namespace BGLi.Web.BankOfScotland.MotorQuote.Controllers;

public class ExtrasController : SecuredController
{
    public ActionResult Index()
    {
        return View();
    }
}