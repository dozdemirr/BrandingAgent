﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Net.Http;

namespace BGLi.Web.BankOfScotland.MotorQuote.Controllers;

[Authorize]
public class KeepAliveController : Controller
{ 
    public HttpResponseMessage Get()
    {
        return new HttpResponseMessage(HttpStatusCode.OK);
    }
}