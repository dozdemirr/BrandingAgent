using System.Web;
using Microsoft.AspNetCore.Mvc;
using BGLi.Security.Web.Authentication.Controllers;

namespace BGLi.Web.BankOfScotland.MotorQuote.Controllers;

public class LegalController : SecuredController
{
    public ActionResult PostPriceImportantInformation()
    {
        return PartialView();
    }

    public ActionResult PrePriceImportantInformation()
    {
        return PartialView();
    }

    public ActionResult Direct()
    {
        return View();
    }

    public ActionResult DirectPrePriceLegal()
    {
        return View();
    }

    public ActionResult AboutUs()
    {
        return PartialView();
    }

    public ActionResult QuoteAcceptanceInformation()
    {
        return PartialView();
    }

    public ActionResult IntermediaryServicesContractSummary()
    {
        return PartialView();
    }
}