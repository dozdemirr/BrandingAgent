using Microsoft.AspNetCore.Mvc;
using BGLi.Security.Web.Authentication.Controllers;

namespace BGLi.Web.BankOfScotland.MotorQuote.Controllers;

public class OtherDetailsController : SecuredController
{
    public ActionResult PaymentsRegularity()
    {
        return View();
    }

    public ActionResult AndFinally()
    {
        return View();
    }
}