using Microsoft.AspNetCore.Mvc;
using BGLi.Security.Web.Authentication.Controllers;

namespace BGLi.Web.BankOfScotland.MotorQuote.Controllers;

public class PricePresentationController : SecuredController
{
    public ActionResult Index()
    {
        return View();
    }

    public ActionResult Breakdown()
    {
        return View();
    }
}