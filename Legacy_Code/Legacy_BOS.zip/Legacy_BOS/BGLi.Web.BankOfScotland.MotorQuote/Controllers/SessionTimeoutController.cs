using Microsoft.AspNetCore.Mvc;

namespace BGLi.Web.BankOfScotland.MotorQuote.Controllers;

public class SessionTimeoutController : Controller
{
    public ActionResult Index()
    {
        return View();
    }
}