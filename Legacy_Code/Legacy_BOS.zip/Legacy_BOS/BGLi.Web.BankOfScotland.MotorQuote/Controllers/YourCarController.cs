using Microsoft.AspNetCore.Mvc;
using BGLi.Security.Web.Authentication.Controllers;

namespace BGLi.Web.BankOfScotland.MotorQuote.Controllers;

public class YourCarController : SecuredController
{
    public ActionResult VehicleLookup()
    {
        return View();
    }

    public ActionResult VehicleDetails()
    {
        return View();
    }

    public ActionResult OvernightParking()
    {
        return View();
    }
}