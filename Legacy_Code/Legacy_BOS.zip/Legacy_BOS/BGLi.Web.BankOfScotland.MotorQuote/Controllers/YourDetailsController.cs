using Microsoft.AspNetCore.Mvc;
using BGLi.Security.Web.Authentication.Controllers;

namespace BGLi.Web.BankOfScotland.MotorQuote.Controllers;

public class YourDetailsController : SecuredController
{
    public ActionResult Index()
    {
        return View();
    }

    public ActionResult MaritalStatus()
    {
        return View();
    }

    public ActionResult Address()
    {
        return View();
    }

    public ActionResult ConfirmedAddress()
    {
        return View();
    }

    public ActionResult HomeOwner()
    {
        return View();
    }

    public ActionResult UkResident()
    {
        return View();
    }

    public ActionResult EmploymentStatus()
    {
        return View();
    }

    public ActionResult EmploymentFlow()
    {
        return View();
    }

    public ActionResult LicenceType()
    {
        return View();
    }

    public ActionResult LicenceDate()
    {
        return View();
    }

    public ActionResult LicenceNumber()
    {
        return View();
    }

    public ActionResult MedicalCondition()
    {
        return View();
    }

    public ActionResult MedicalConditionDvlaNotified()
    {
        return View();
    }

    public ActionResult DeclinedInsurance()
    {
        return View();
    }

    public ActionResult MotorClaims()
    {
        return View();
    }

    public ActionResult MotorConvictions()
    {
        return View();
    }

    public ActionResult CriminalConvictions()
    {
        return View();
    }

    public ActionResult AdditionalDrivers()
    {
        return View();
    }
}