﻿using BGLi.Components.CoverDetails;
using BGLi.Components.CoverDetails.Configuration.CoverLevel;
using BGLi.Components.CoverDetails.Configuration.CoverListWidgetItem;
using BGLi.Components.CoverDetails.Enums;
using System.Collections.Generic;

namespace BGLi.Web.BankOfScotland.MotorQuote.Helpers;

public static class CoverLevels
{
    private const string Damage = "Cover for loss or damage to your car caused by accidental or malicious damage, fire, theft or attempted theft, or vandalism";
    private const string ThirdPartyDamage = "Cover for loss or damage to your car caused by fire, theft or attempted theft";

    private const string Glass = "Damage to glass";
    private const string NoGlass = "There is no cover for glass claims unless caused directly by fire or theft";
    private const string NoGlassAtAll = "There is no cover for glass claims";
        
    private const string Abroad = "Driving abroad - up to 60 days cover at the same level as your UK car insurance policy";
    private const string AbroadMinimum = "Third Party Only cover whilst travelling abroad for up to 60 days cover in any one policy term";
    private const string ThirdPartyAbroad = "Third Party Fire and Theft cover whilst travelling abroad for up to 60 days in any one policy term";

    private const string DrivingOtherCars = "Driving other cars cover only applies if shown on your certificate of motor insurance";
        
    private const string Liability = "Your liability to any person for death, bodily injury, or damage to property caused by an accident involving your car";

    private const string NoAccidentalCover = "There is no cover for damage to your car caused by accidental or malicious damage";
    private const string NoAccidentalCoverThirdsPartyOnly = "There is no cover for loss or damage to your car caused by accidental or malicious damage, fire, theft or attempted theft";
    private const string IncorrectFuelling = "Loss or damage resulting from incorrectly maintaining or fuelling the car is not covered";
    private const string KeysLeftUnattended = "There is no cover for theft if the keys are left in or on the car while it is left unattended";

    private static readonly string _noVariant = string.Empty;
        
    public static ComponentCoverDetailsConfiguration AddCoverLevelOptions(this ComponentCoverDetailsConfiguration configuration)
    {
        return (ComponentCoverDetailsConfiguration)((ICoverLevelOptionsConfiguration)configuration).AddCoverLevelOptions();
    }

    public static CoverLevelConfiguration AddCoverLevelOptions(this CoverLevelConfiguration configuration)
    {
        return (CoverLevelConfiguration)((ICoverLevelOptionsConfiguration)configuration).AddCoverLevelOptions();
    }

    public static CoverDetailsComponentCoverLevelWidgetItemConfiguration AddCoverLevelOptions(
        this CoverDetailsComponentCoverLevelWidgetItemConfiguration configuration)
    {
        return (CoverDetailsComponentCoverLevelWidgetItemConfiguration)((ICoverLevelOptionsConfiguration)configuration).AddCoverLevelOptions();
    }

    private static ICoverLevelOptionsConfiguration AddCoverLevelOptions(this ICoverLevelOptionsConfiguration config)
    {
        config
            .AddComprehensiveOption(
                _noVariant,
                GetComprehensiveBenefits(),
                GetComprehensiveThingsToRemember(),
                ProductType.Car)
            .AddThirdPartyFireAndTheftOption(
                _noVariant,
                GetThirdPartyFireAndTheftBenefits(),
                GetThirdPartyFireAndTheftThingsToRemember(),
                ProductType.Car)
            .AddThirdPartyOnlyOption(
                _noVariant,
                GetThirdPartyOnlyBenefits(),
                GetThirdPartyOnlyThingsToRemember(),
                ProductType.Car);
        return config;
    }

    private static List<string> GetComprehensiveBenefits()
    {
        return new List<string> { Damage, Glass, Abroad };
    }

    private static List<string> GetComprehensiveThingsToRemember()
    {
        return new List<string> { IncorrectFuelling, KeysLeftUnattended, DrivingOtherCars };
    }

    private static List<string> GetThirdPartyFireAndTheftBenefits()
    {
        return new List<string> { ThirdPartyDamage, Liability, ThirdPartyAbroad };
    }

    private static List<string> GetThirdPartyFireAndTheftThingsToRemember()
    {
        return new List<string> { NoAccidentalCover, NoGlass, KeysLeftUnattended, DrivingOtherCars };
    }

    private static List<string> GetThirdPartyOnlyBenefits()
    {
        return new List<string> { Liability, AbroadMinimum };
    }

    private static List<string> GetThirdPartyOnlyThingsToRemember()
    {
        return new List<string> { NoAccidentalCoverThirdsPartyOnly, DrivingOtherCars, NoGlassAtAll };
    }
}