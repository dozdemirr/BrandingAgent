using BGLi.BaseApp.BaseApplication.Attributes;
using BGLi.BaseApp.BaseApplication.Extensions;
using BGLi.Security.Web.Authentication.Extensions;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);
builder.Services
    .Configure<CookiePolicyOptions>(options =>
    {
        options.Secure = CookieSecurePolicy.Always;
    })
    .RegisterApiHandlerAndServices()
    .ConfigureServicesAndAddBglDependencies(
        builder.Configuration["ApplicationInsights:ConnectionString"],
        builder.Configuration["TenantConfiguration:ApplicationPath"])
    .AddMotorQuoteConfiguration(builder.Configuration)
    .AddBglCookieAuth(builder.Configuration)
    .AddBglDataProtection(
        builder.Environment.ContentRootPath + "\\Keys\\",
        !builder.Environment.IsDevelopment())
    .AddControllers(options =>
    {
        options.Filters.Add(typeof(BackRedirectAttribute));
    });

var app = builder.Build();
 
// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error/Index");
    app.UseHsts();
}

app.SetupWebApp(
    string.Format(
        "{0}/{1}",
        builder.Configuration["TenantConfiguration:ApplicationPath"].TrimEnd('/'),
        builder.Configuration["NoQuoteRedirectUrl"].TrimStart('/')),
    builder.Configuration["ErrorRedirectUrl"]);
app.UseCookiePolicy(new CookiePolicyOptions
{
    MinimumSameSitePolicy = SameSiteMode.None
});

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=SessionTimeout}/{action=Index}/{id?}");
 
app.Run();